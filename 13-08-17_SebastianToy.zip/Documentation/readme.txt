~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Artifical Intelligence Project
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
=======================================================================================================================================================
1. HOW TO START THE GAME
------------------------
- Run the .exes in ProjectRelease/AIProject.
- To compile, open up Bootstrap and 'Add Existing Project' for 2017_07_17_AIPractise_stoy.vcxproj
	- There is a limitation of Visual Studio which is that it may not compile if the total directory length is too long. To avoid this, drag the source folder
	 to something more direct like the C drive.
        - Occasionally it may throw up a MSVCRT default lib error OR insufficient permissions to write this file, to fix this rebuild the solution.

=======================================================================================================================================================
2. GAME FEATURES
----------------
- NPCs use 3 different Decision Making Techniques that use custom classes and structures:
	- Each NPC uses a Finite State Machine to transition between states. 
	- Each NPC interfaces with a Blackboard in order to determine the best course of action for the current frame, as well as influence the decisions
	of other npcs (e.g. an NPC guard finds the player and sends a message, NPC minions then change to a converging state).
	- Utility AI decision making for the states, each state has a utility score and every update the state with the most utility will be set
	 by the NPC's Finite State Machine.

- A* grid path-finding that allows for custom lambdas to be passed in to calculate the H score
	- Ability for multiple NPCs to plan out and follow paths with minimal lag.

- 5 Steering Behaviours used by NPCs
	- Seek/Flee
	- Follow Path
	- Wander
	- Collision Avoidance against circles, rectangles and triangles.
	- Arrival

- Steering forces are scaled with automatic weighted combination, a factor determined by the scale of all other active behaviours.
=======================================================================================================================================================
3. HOW TO PLAY
----------------
- Use WASD to move the white dot around.
	- If you move into one of the NPC Guard's (indicated by large yellow circle) search circle, all minions (small aqua circles) will converge on 
	the guard's position for a given time.
	- After converging for a few seconds, the minions will all touch base with a given point on the map before continuing to patrol again.
=======================================================================================================================================================
4. KNOWN BUGS
----------------
- The collision checks on the window planes are iffy, sometimes npcs will get stuck just under the window frame and be unable to move.

- Moving into one of the guard's search radius' will sometimes cause the guard to spot you but then immediately ignore it and go back to patrolling.

- Due to the combination of weighted forces, collision avoidance may cause guards and minions to pass through obstacles, although they will do their best to avoid them.

5. REPOSITORY LINKS
--------------------
AI Project: 	       https://github.com/DarthDementous/Bootstrap_AI_Practise
State Manager Library: https://github.com/DarthDementous/2017_05_29_GameStateManagement
=======================================================================================================================================================