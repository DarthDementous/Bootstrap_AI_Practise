#include "Obstacles/IObstacle.h"
#include <Renderer2D.h>

void IObstacle::Render(aie::Renderer2D * a_r2d)
{

}
